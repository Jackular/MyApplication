package com.applepie.blackba;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    EditText mDate;
    TextView mNext;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        mDate = (EditText) findViewById(R.id.date);
        mNext = (TextView) findViewById(R.id.next);

//      final  MyEditTextDatePicker myEditTextDatePicker=new MyEditTextDatePicker(MainActivity.this,R.id.date);

//        mDate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                myEditTextDatePicker.onClick(view);
//            }
//        });

        mNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,TimeDetails.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
